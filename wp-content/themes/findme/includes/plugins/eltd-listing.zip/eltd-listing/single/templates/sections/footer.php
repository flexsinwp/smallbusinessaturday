<div class="eltd-ls-single-footer eltd-grid">
	<div class="eltd-ls-single-section">
		<?php echo eltd_listing_single_template_part('parts/related-posts');?>
	</div>
</div>