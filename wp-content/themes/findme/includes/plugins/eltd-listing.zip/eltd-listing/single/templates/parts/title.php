<div class="eltd-breadcrumbs-holder">
    <?php findme_elated_custom_breadcrumbs(); ?>
</div>
<div class="eltd-ls-item-title">
	<h3 class="eltd-ls-item-title-inner">
		<?php echo get_the_title(); ?>
	</h3>
</div>