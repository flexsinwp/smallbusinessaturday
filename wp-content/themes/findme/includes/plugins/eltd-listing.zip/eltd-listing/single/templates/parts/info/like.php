<?php if( function_exists('findme_elated_get_like') ) {
    ?>
    <div class="eltd-ls-header-info eltd-ls-like">
        <?php findme_elated_get_like(); ?>
    </div>
<?php } ?>