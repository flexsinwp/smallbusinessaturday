<?php

define('ELATED_BOOKING_VERSION', '1.0');
define('ELATED_BOOKING_ABS_PATH', dirname(__FILE__));
define('ELATED_BOOKING_REL_PATH', dirname(plugin_basename(__FILE__ )));