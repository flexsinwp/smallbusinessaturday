<div class="eltd-register-notice">
    <h5><?php echo esc_html($message); ?></h5>
    <a href="#" class="eltd-login-action-btn" data-el="#eltd-login-content" data-title="<?php esc_html_e('Log in', 'eltd-membership'); ?>">
		<?php esc_html_e('Log in', 'eltd-membership'); ?>
    </a>
</div>