<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/fullscreen-objects/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/fullscreen-objects/fullscreen-objects.php';