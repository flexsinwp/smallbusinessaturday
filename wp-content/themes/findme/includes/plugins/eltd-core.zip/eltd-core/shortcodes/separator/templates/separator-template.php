<div class="eltd-separator-holder clearfix  <?php echo esc_attr($separator_class); ?>">
	<div class="eltd-separator" <?php echo findme_elated_get_inline_style($separator_style); ?>></div>
</div>
