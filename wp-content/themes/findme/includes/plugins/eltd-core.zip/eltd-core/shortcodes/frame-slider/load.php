<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/frame-slider/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/frame-slider/frame-slider.php';