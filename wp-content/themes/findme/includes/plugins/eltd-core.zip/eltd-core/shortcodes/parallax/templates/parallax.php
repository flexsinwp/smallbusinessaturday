<div class="eltd-parallax-holder <?php echo esc_attr($holder_class); ?>" <?php echo findme_elated_get_inline_attrs($holder_data); ?> <?php echo findme_elated_get_inline_style($holder_style); ?>>
	<div class="eltd-parallax-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>
