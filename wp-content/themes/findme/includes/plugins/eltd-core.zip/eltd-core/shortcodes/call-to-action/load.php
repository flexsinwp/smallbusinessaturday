<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/call-to-action/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/call-to-action/call-to-action.php';