<?php

include_once ELATED_CORE_SHORTCODES_PATH.'/image-with-icon/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH.'/image-with-icon/image-with-icon.php';