<?php

include_once ELATED_CORE_CPT_PATH.'/team/team-register.php';
include_once ELATED_CORE_CPT_PATH.'/team/helper-functions.php';
include_once ELATED_CORE_CPT_PATH.'/team/shortcodes/shortcodes-functions.php';