<?php

get_header();

findme_elated_get_title();

eltd_core_get_single_team();

get_footer();