<?php

get_header();

findme_elated_get_title(false, 'portfolio_single');

eltd_core_get_single_portfolio();

get_footer();