<?php if($query_results->max_num_pages > 1) { ?>
	<div class="eltd-pl-loading">
		<div class="eltd-pl-loading-bounce1"></div>
		<div class="eltd-pl-loading-bounce2"></div>
		<div class="eltd-pl-loading-bounce3"></div>
	</div>
<?php }