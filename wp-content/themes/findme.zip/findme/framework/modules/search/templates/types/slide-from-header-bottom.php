<div class="eltd-slide-from-header-bottom-holder">
	<form action="<?php echo esc_url(home_url('/')); ?>" method="get">
	    <div class="eltd-form-holder">
	        <input type="text" placeholder="<?php esc_html_e('Search', 'findme'); ?>" name="s" class="eltd-search-field" autocomplete="off" />
	        <button type="submit" class="eltd-search-submit"><span class="icon_search "></span></button>
	    </div>
	</form>
</div>