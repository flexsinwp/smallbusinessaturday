<?php

if (findme_elated_visual_composer_installed()) {
	include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/visualcomposer/visual-composer-config.php';
}