<?php

include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-tabbed/functions.php';
include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-tabbed/header-tabbed.php';