<?php

include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-top-menu/functions.php';
include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-top-menu/header-top-menu.php';