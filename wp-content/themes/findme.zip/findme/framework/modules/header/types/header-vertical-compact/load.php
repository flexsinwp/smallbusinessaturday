<?php

include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-vertical-compact/functions.php';
include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-vertical-compact/header-vertical-compact.php';