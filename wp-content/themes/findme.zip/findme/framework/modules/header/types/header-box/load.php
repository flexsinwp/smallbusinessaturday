<?php

include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-box/functions.php';
include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-box/header-box.php';