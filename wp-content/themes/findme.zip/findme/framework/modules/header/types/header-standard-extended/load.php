<?php

include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-standard-extended/functions.php';
include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-standard-extended/header-standard-extended.php';