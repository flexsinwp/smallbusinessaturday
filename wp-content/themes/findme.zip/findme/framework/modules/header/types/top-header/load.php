<?php

include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/top-header/functions.php';