<?php

include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-vertical-closed/functions.php';
include_once ELATED_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-vertical-closed/header-vertical-closed.php';