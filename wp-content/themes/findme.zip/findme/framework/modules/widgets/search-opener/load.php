<?php

require_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/search-opener/search-opener.php';
