<div class="eltd-blog-like">
	<?php if( function_exists('findme_elated_get_like') ) findme_elated_get_like(); ?>
</div>