<div class="eltd-post-info-category">
    <?php echo findme_elated_icon_collections()->renderIcon('lnr-bookmark', 'linear_icons'); ?>
    <?php the_category(', '); ?>
</div>