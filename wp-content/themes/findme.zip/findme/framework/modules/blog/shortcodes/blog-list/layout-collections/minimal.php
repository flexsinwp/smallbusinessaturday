<li class="eltd-bl-item clearfix">
	<div class="eltd-bli-inner">
		<div class="eltd-bli-content">
            <?php findme_elated_get_module_template_part('templates/parts/title', 'blog', '', $params); ?>
            <?php findme_elated_get_module_template_part('templates/parts/post-info/date', 'blog', '', $params); ?>
		</div>
	</div>
</li>