<li class="eltd-bl-item clearfix">
	<div class="eltd-bli-inner">
        <?php findme_elated_get_module_template_part('templates/parts/image', 'blog', 'simple', $params); ?>
		
		<div class="eltd-bli-content">
            <?php findme_elated_get_module_template_part('templates/parts/title', 'blog', '', $params); ?>
			<?php findme_elated_get_module_template_part('templates/parts/post-info/date', 'blog', '', $params); ?>
			<?php findme_elated_get_module_template_part('templates/parts/post-info/comments', 'blog', '', $params); ?>
		</div>
	</div>
</li>