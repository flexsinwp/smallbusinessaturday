<?php

include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/footer/options-map/map.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/footer/custom-styles/custom-styles.php';
include_once ELATED_FRAMEWORK_MODULES_ROOT_DIR.'/footer/functions.php';